"""LickStagePlugin（舔舐行為二階段分析）專屬設定，除了 Node-RED 端點主機/port
外，獨立於主專案 config.py。

Node-RED 端點例外：這裡的 NODERED_URL 過去是完全獨立寫死的
"http://127.0.0.1:1880/..."，跟主專案 config.py 的 NodeRedConfig.HOST/PORT
（有 CAT_MONITORING_NODERED_HOST/PORT 可覆寫）互不相干——改了主設定，這個
plugin 的推送目標不會跟著變，而且失敗時原本是完全靜默的（見
plugins/lick_stage/publisher.py），不容易發現資料悄悄停止送達。2026-08-10
起改成預設從 NodeRedConfig.HOST/PORT 組出來，仍可用獨立的環境變數單獨覆寫
（例如這個 plugin 實際上要送到跟主流程不同的 Node-RED 實例時）。詳見
docs/資料層架構現況與統一管理評估.md 第十一節。
"""

from config import NodeRedConfig as _NodeRedConfig

# 2026-08-11：_env_str/_env_float 原本在這裡各自重複實作一份（跟
# analytics/config.py、plugins/lick_stage/ext_body_zones/config.py 幾乎
# 一模一樣），改成共用 utils/env_parsing.py——注意這仍然是匯入
# cat_monitoring_system 套件內部的模組，不是匯入頂層 paper/config.py，
# 沒有違背上面「Node-RED 端點例外」段落講的「不跟主設定耦合」原則（那條
# 原則講的是不要依賴 paper/config.py 裡跟這個 plugin 無關的操作性設定，
# 不是禁止共用同一個套件內、純函式、無狀態的字串/數字解析工具）。
from utils.env_parsing import env_float as _env_float, env_str as _env_str


class LickConfig:
    """舔舐區域判定、頭部朝向平滑與 Node-RED 回報所需的所有門檻與參數。"""

    # ── 關鍵點索引（對應 YOLO-Pose 輸出的骨架編號） ───────────────────────
    KP_NOSE = 0  # 鼻子
    KP_LEFT_EAR = 1  # 左耳
    KP_RIGHT_EAR = 2  # 右耳
    KP_CHEST = 3  # 胸部
    KP_MID_BACK = 4  # 背部中心（標記於背部最高點，非 chest-hip 連線中點）
    KP_HIP = 5  # 髖部

    # LIMB_SEGMENTS: (群組標籤, 膝關節索引, 腳掌索引)
    LIMB_SEGMENTS = [
        ("FL", 6, 7),  # 前左肢  膝=6, 腳掌=7
        ("FR", 8, 9),  # 前右肢  膝=8, 腳掌=9
        ("HL", 10, 11),  # 後左肢  膝=10, 腳掌=11
        ("HR", 12, 13),  # 後右肢  膝=12, 腳掌=13
    ]

    # ── 關鍵點信心值門檻 ──────────────────────────────────────────────────
    EAR_CONF_THRESHOLD = 0.3  # 耳朵關鍵點最低信心值，低於此值視為耳朵不可見
    NOSE_CONF_THRESHOLD = 0.3  # 鼻子關鍵點最低信心值，低於此值視為鼻子不可用（影響接觸判定與頭部朝向判斷）
    LIMB_CONF_THRESHOLD = 0.10  # 四肢關鍵點最低信心值，低於此值跳過該肢體
    BODY_KP_CONF = 0.5  # 胸部/髖部信心值門檻，用於計算身體尺度

    # ── 狀態平滑窗口 ──────────────────────────────────────────────────────
    STATE_SMOOTH_WINDOW = 30  # 頭部朝向狀態平滑的滑動窗口大小（幀數）

    # ── 頭部朝向狀態標籤 ─────────────────────────────────────────────────
    STATE_UNKNOWN = "UNKNOWN"  # 無法判斷朝向
    STATE_FRONT = "FACING_CAMERA"  # 正面朝向鏡頭
    STATE_FRONT_LEFT = "FRONT_LEFT"  # 偏左的正面
    STATE_FRONT_RIGHT = "FRONT_RIGHT"  # 偏右的正面
    STATE_BACK = "BACK_VIEW"  # 背對鏡頭
    STATE_FRONT_VIEW = "FRONT_VIEW"  # 前視圖保護觸發（抑制舔舐判定）
    STATE_NO_CAT = "NO_CAT"  # 畫面中無貓

    # ── 貓咪視角凝視方向門檻（以貓咪身體坐標系為基準） ──────────────────
    CAT_FRONT_FORWARD_MIN = 0.08  # 判定「朝前」所需的前向分量最小值
    CAT_BACK_FORWARD_MIN = 0.10  # 判定「背後」所需的前向分量最小值
    CAT_LR_MARGIN = 0.06  # 左右偏移容許誤差（小於此值視為正中）
    CAT_LR_SIGN = 1.0  # 左右方向符號（+1 = 無翻轉；-1 = 鏡像）

    # ── 使用者規則門檻（角度/距離輔助判斷頭部朝向） ──────────────────────
    FRONT_CAMERA_ANGLE_MIN_DEG = 45.0  # 耳鼻夾角超過此值（度）判定為面朝鏡頭
    FRONT_CAMERA_NORM_MIN = 0.30  # 耳間距標準化值超過此值輔助判定為正面
    BACK_CAMERA_NOSE_CONF_MAX = 0.5  # 背對時鼻子信心值上限（高於此值不認為是背對）
    BACK_CAMERA_DIST_MIN_PX = 3.0  # 判定背對所需的耳間距最小像素值
    BACK_VIEW_REQUIRE_LOW_NOSE = True  # True = 背對判定要求鼻子信心值必須低於門檻

    # ── 正面視圖保護（front-view guard）────────────────────────────────
    # 啟用後，當耳間距與身體尺度比值過大（貓面朝鏡頭）時，
    # 暫停舔舐接觸判定，避免誤判。
    FRONT_VIEW_GUARD_ENABLED = True  # 是否啟用正面保護機制
    FRONT_VIEW_BODY_EAR_RATIO_MAX = 0.75  # 耳間距/身體尺度比值超過此值即觸發保護

    # ── 混合尺度（M5，取代舊的絕對像素夾鉗 CONTACT_BODY_LEN_MIN/MAX_PX）───
    # 舊版用固定 300–650px 夾鉗 body_len（chest-hip 直線距離），隱含「攝影機
    # 距離大致固定」的假設；貓咪蜷曲理毛時 chest-hip 直線距離會被姿態壓縮
    # （跟 CURVATURE_* 想解決的問題同源，但那組只補償梯形尺寸，沒補償
    # 「鼻子接觸梯形」與「四肢／腳尖」共用的 eff_len 本身），夾到固定下限反而
    # 讓幾何尺寸系統性偏離真實比例。改用 _compute_body_scale()（見
    # contact_regions.py）三層 fallback：mid_back 信心足夠時用
    # chest-midback-hip 折線長（抵抗蜷曲造成的直線壓縮）→ 退回 chest-hip
    # 直線距離 → 退回 bbox 對角線 × 下面這個比例常數。
    SCALE_DEGENERATE_LEN_PX = 20.0  # 折線/直線長度低於此值視為偵測本身有問題（不是姿態彎曲），才觸發 bbox fallback
    BBOX_TO_BODY_LEN_RATIO = 0.65  # bbox_fallback 時 body_len ≈ bbox 對角線 × 此比例；粗略預設值，若 verify 工具顯示 bbox_fallback 頻繁觸發需依實測重新校準

    # ── 鼻子接觸梯形幾何參數 ──────────────────────────────────────────────
    # 全部是相對身體長度的比例常數，不是絕對物理單位：單眼 2D 攝影機無法
    # 分辨「大貓遠」跟「小貓近」，任何看似有物理單位（例如公分）的描述
    # 都只是換算出來的比例，統一用比例常數表達，不假裝有絕對單位。
    NOSE_TRAP_THICKNESS_RATIO = 0.055  # 梯形厚度 = 身體長度 × 此比例
    NOSE_TRAP_THICKNESS_SCALE = 1.0  # 梯形厚度縮放係數（1.0 = 不縮放）
    NOSE_TRAP_TOP_W_RATIO = 0.10  # 梯形頂寬 = 身體長度 × 此比例
    NOSE_TRAP_BOT_W_RATIO = 0.20  # 梯形底寬 = 身體長度 × 此比例
    NOSE_TRAP_W_SCALE = 1.15  # 梯形整體寬度額外放大係數

    # ── 梯形彎曲自適應（Chest-MidBack-Hip 夾角，驅動梯形縮放）──────────────
    # mid_back 標記在貓咪背部最高點（非 chest-hip 連線中點）。貓咪拱背/蜷曲
    # 理毛時，該點會明顯偏離 chest-hip 直線，此時 body_len（chest-hip 直線
    # 距離）會因姿態彎曲而低估「真實」身體尺度，導致鼻子接觸梯形在最需要
    # 精準判定的姿態下反而系統性偏小。這裡用 Chest-MidBack-Hip 夾角（以
    # MidBack 為頂點）當彎曲程度指標，線性映射成縮放倍率回補，只套用在
    # 梯形尺寸上（不影響身體橢圓/四肢區域，那些量測的是「當下真實」幾何，
    # 不該被姿態推測放大縮小）。
    #
    # 公式與角度區間跟 processors/skeleton_quality_assessment.py 的
    # compute_midback_angle()／CANDIDATE_MIDBACK_ANGLE_LOW/HIGH_THRESHOLD
    # 共用同一套幾何定義與經驗值（該模組依少量影片校準，未來重新校準時
    # 兩處要一起調整）；contact_regions.py 內另外重新實作一份同款公式
    # （不 import processors/ 模組），維持本 plugin 低耦合、可獨立抽離的
    # 既有設計原則。
    CURVATURE_ANGLE_MAX_DEG = 160.0  # 夾角上限：越接近此值代表脊椎越直（對齊 SQA CANDIDATE_MIDBACK_ANGLE_HIGH_THRESHOLD）
    CURVATURE_ANGLE_MIN_DEG = 20.0  # 夾角下限：越接近此值代表拱背/蜷曲程度越明顯（對齊 SQA CANDIDATE_MIDBACK_ANGLE_LOW_THRESHOLD）
    CURVATURE_BOOST_MIN = 0.85  # 對應 CURVATURE_ANGLE_MAX_DEG（打直）時的梯形縮放倍率（打直時縮小）
    CURVATURE_BOOST_MAX = 1.20  # 對應 CURVATURE_ANGLE_MIN_DEG（拱背/蜷曲）時的梯形縮放倍率（拱背時放大）

    # ── 身體中心（橢圓）區域幾何參數 ──────────────────────────────────────
    BODY_ELLIPSE_W_RATIO = 0.65  # 身體橢圓寬度 = 身體長度 × 此比例
    BODY_ELLIPSE_H_RATIO = 0.27  # 身體橢圓高度 = 身體長度 × 此比例
    ELLIPSE_SAMPLES = 40  # 橢圓邊界取樣點數（用於判斷鼻子是否在橢圓內）；取樣點越多精度越高，但計算量略增

    # ── 四肢（長條）接觸區域幾何參數 ──────────────────────────────────────
    LIMB_CONTACT_SCALE = 1.0  # 四肢接觸區域整體縮放係數（同時套用在下面的長條與腳尖圓上）
    LIMB_STRIP_HW_RATIO = 0.055  # 四肢長條寬度 = 身體長度 × 此比例
    LIMB_STRIP_EDGE_GAP = 0.0  # 四肢長條與腳尖圓之間的間距 = 身體長度 × 此比例（0 = 緊鄰）

    # ── 腳尖（圓形）接觸區域幾何參數 ──────────────────────────────────────
    LIMB_PAW_CIRCLE_R_RATIO = 0.05  # 腳尖圓圈半徑 = 身體長度 × 此比例

    # ── 關鍵點 EMA 平滑（1.0 = 不平滑，直接使用原始值） ─────────────────
    # 只影響本 plugin 內部的接觸判定/overlay 穩定度，與 ST-GCN 推論用的
    # kp_ema_alpha（frame_processor 傳入的是 raw_kpts）完全independent。
    # M4 第二階段接線後，這個值不再由 analyzer.py 自己套用（見
    # analyzer.py::_handle_cat 的說明）——改由 frame_processor.py 建構的共用
    # PoseFilter 套用同一個 alpha，analyzer.py 收到的 kpts 已經是平滑過的。
    EMA_ALPHA = 0.4  # 指數移動平均係數；調低可平滑抖動，但會增加延遲

    # ── M4：共用 PoseFilter 參數（frame_processor.py 建構共用實例時使用，
    # 見該檔案 __init__ 與 _notify_plugins()）──────────────────────────────
    # alpha 沿用上面既有的 EMA_ALPHA，維持現行平滑強度不變，只是從「樸素
    # EMA」升級成「信心值感知 EMA」（見 pose_filter.py）。
    POSE_FILTER_ALPHA = EMA_ALPHA
    # min_conf 借用本檔既有 LIMB_CONF_THRESHOLD（0.10，本檔目前最寬鬆的
    # 關鍵點可信度下限），全域套用在所有 17 個關鍵點——粗略起手值，這是
    # 全新啟用的機制（analyzer.py 舊版樸素 EMA 沒有這一層），之後應依真實
    # 影片觀察 hold-decay 實際觸發頻率再重新校準，不同關鍵點（鼻子/耳朵 vs.
    # 四肢）目前共用同一個門檻，尚未分開處理。
    POSE_FILTER_MIN_CONF = LIMB_CONF_THRESHOLD
    # hold_decay_frames 用「秒數 × 呼叫端實際 source_fps」換算（frame_processor.py
    # 換算），這裡先定秒數；跟 GAP_TOLERANCE_SEC 同樣取「短暫遮蔽/漏偵測」
    # 的典型時間量級（0.5 秒），但這是接住「同一批關鍵點連續低信心」的獨立
    # 門檻，語意跟 bout 邊界的 GAP_TOLERANCE_SEC 不同，刻意不共用同一個常數。
    # 粗略起手值，之後可依實測重新校準。
    POSE_FILTER_HOLD_DECAY_SEC = 0.5

    # ── 鼻子接觸梯形方向向量穩定化（解決貓側躺/頭部縮短時梯形抖動亂轉）──
    # trap_perp（耳線方向）對雜訊極敏感（耳間距短時尤其明顯），用「翻轉感知
    # EMA」+「連續反向才確認」跨幀穩定：新向量若與前一幀方向明顯相反，先翻轉
    # 再平均，避免兩個反向向量直接相加抵消；同時提供緩衝區間與確認幀數，噪音
    # 在邊界附近來回時不會讓 trap_perp 整個 180° 亂轉，只有連續多幀都反向
    # （例如貓真的轉身）才會被接受為真正的方向改變。
    TRAP_PERP_EMA_ALPHA = 0.35  # trap_perp 的 EMA 係數（越小越穩定，但轉向反應越慢）
    TRAP_PERP_FLIP_MARGIN = (
        0.15  # 內積需低於 -此值才視為「真的反向」，避免邊界抖動誤觸發翻轉
    )
    # 連續幾幀都判定為「反向」才接受為真正的方向改變（例如貓轉身）；
    # 少於此幀數視為單幀雜訊，暫時忽略、沿用前一個穩定方向，避免被雜訊拉走
    TRAP_PERP_FLIP_CONFIRM_FRAMES = 6

    # trap_dir（梯形延伸方向）改由 trap_dir_from_perp() 從穩定後的 trap_perp
    # 決定性推導，強制指向影像下方（鼻子/短邊保證在上面，貓咪不會倒著理毛）。
    # 但這個推導出來的候選值仍會因 trap_perp 殘留的微小雜訊而在自己的判斷
    # 邊界（trap_perp 幾乎與畫面垂直，即耳朵連線幾乎垂直、貓側躺頭部縮短時）
    # 跳動，而且這個雜訊已經是 EMA 平滑過的、具有時間相關性，用「連續反向
    # 才確認」的計數方式反而容易被平滑雜訊的自然延續性誤判成真的轉向。
    # 因此 trap_dir 只用純翻轉感知 EMA（不做確認幀數計數），並採用更強的
    # 平滑（更小的 alpha）壓下殘留雜訊——若 trap_perp 真的持續反向，
    # trap_perp 自己的確認機制會先接受新方向，trap_dir 隨後自然會平滑跟上，
    # 不需要獨立的「瞬間接受」機制。
    #
    # 注意：FLIP_MARGIN 必須維持「窄」（接近 0），不能為了「減少誤觸發翻轉」
    # 而調寬——寬邊界會讓「明顯但未達邊界」的反向讀數被直接拿去平均而非先
    # 翻轉，兩個部分抵銷的向量疊加會讓 EMA 狀態的長度被拉向 0，之後重新
    # 正規化（除以趨近 0 的長度）會把方向放大成任意雜訊，反而更不穩定。
    TRAP_DIR_EMA_ALPHA = 0.12
    TRAP_DIR_FLIP_MARGIN = 0.15

    # trap_dir 的「長期方向卡死」安全網：上面的純 EMA 追蹤完全信任
    # _prev_trap_dir 這個歷史錨點，只要初始化那一刻（或貓消失重新出現後
    # 重新初始化那一次）trap_dir_from_perp() 定出的方向剛好不符合直覺
    # （鼻子/短邊在上、身體/長邊在下），後續就會一路「穩定地」錯下去，
    # 因為 EMA 只追求跟前一幀連續、不會主動驗證 y>=0 這個物理假設。
    # 這裡不做「每幀強制」（那樣會在梯形接近水平時造成硬性翻轉抖動，
    # 見上方 trap_dir 段落說明），而是隔離成一道獨立的安全網：只有連續
    # 好幾幀都偏離 y>=0（不是臨界抖動，是真的卡在錯誤方向）才強制拉回，
    # 平常的水平抖動只會讓計數器歸零，不會觸發翻轉。
    TRAP_DIR_WRONG_SIDE_CONFIRM_FRAMES = 10

    # ── 區域標籤 ─────────────────────────────────────────────────────────
    ZONE_NO_TARGET = "NO_TARGET"  # 鼻子未命中任何區域
    ZONE_BODY = "BODY_CENTER"  # 命中身體中心區域
    ZONE_AMBIGUOUS = "AMBIGUOUS"  # M5：候選評分最高分與次高分差距小於 AMBIGUITY_MARGIN，無法可靠分辨

    # ── 候選評分與 AMBIGUOUS（M5，取代 find_nearest_zone() 舊版純距離排序）──
    # 鼻子接觸梯形若同時跟兩個相鄰區域都有明顯重疊（例如剛好在身體與前肢
    # 交界處），舊版直接選「距離最近」的那個，武斷且沒有反映真正的不確定性。
    # 現在改成每個候選算正規化分數（1 - 距離/該候選區域特徵尺度，見
    # find_nearest_zone() 說明），最高分跟次高分差距小於此值時回傳
    # ZONE_AMBIGUOUS，而不是硬選一個。粗略預設值，之後可依實測（不同候選
    # 分數的實際分布）重新校準。
    AMBIGUITY_MARGIN = 0.15

    # ── Bout 狀態機（M6，取代 event_aggregator.py 舊版「一遇到非 lick 幀就
    # 結算」的粗聚合，見 action_gate.py）─────────────────────────────────
    # START/CONTINUE 不是兩個信心數值門檻，是兩組寬鬆度不同的 FrameState
    # 集合（見 action_gate.py 開頭說明）：START 沿用 FrameState.LICK（跟
    # 原本開始一個 bout 的條件一致）；CONTINUE 額外容許 LOW_LICK_CONF——
    # 已經在舔毛的情況下，信心值短暫掉到 M1 的 low_conf_threshold 以下
    # 不會馬上結束事件，這就是 hysteresis，不是新發明一套原始浮點數門檻
    # （lick_confidence 在 is_lick=False 時語意上不是「P(lick)」，見
    # action_gate.py 的說明，故意不直接拿它做二次門檻）。
    #
    # GAP_TOLERANCE_SEC：CONTINUE 條件都不滿足（真的是 NOT_LICK/NO_CAT）
    # 時，先不結束 bout，給這麼多秒的寬限期；寬限期內恢復就當沒中斷過。
    # 粗略預設值（半秒——貓咪換個角度、模型漏偵測一兩幀的典型時間量級），
    # 之後可依實測（不同影片的真實停頓分布）重新校準。
    GAP_TOLERANCE_SEC = _env_float("CAT_MONITORING_LICK_GAP_TOLERANCE_SEC", 0.5)
    # MIN_BOUT_SEC：bout 真正關閉時，若累積的（CONTINUE 條件下的）舔毛時長
    # 低於這個值，整段丟棄，不產生事件——避免零星幾幀誤判被聚成一筆「事件」
    # 污染事件表。粗略預設值，之後可依實測重新校準。
    MIN_BOUT_SEC = _env_float("CAT_MONITORING_LICK_MIN_BOUT_SEC", 0.5)

    # ZONE_SWITCH_MIN_SEC（M6 第二部分，見 bout_aggregator.py）：同一個
    # raw bout 內部，候選 zone 要連續累積這麼多秒才算「真的換部位」，
    # 觸發子事件切分；累積不夠又跳回原 zone 就當雜訊抖動吸收掉，不切分。
    # 粗略預設值（1 秒——比 GAP_TOLERANCE_SEC 更保守，避免候選評分在相鄰
    # zone 間的正常抖動被誤判成真的換部位），之後可依實測重新校準。刻意
    # 大於 MIN_BOUT_SEC，避免「子事件已送出、但整個 raw bout 事後被
    # min_bout 丟棄」的邊界情形（見 bout_aggregator.py 開頭「呼叫端注意
    # 事項」）。
    ZONE_SWITCH_MIN_SEC = _env_float("CAT_MONITORING_LICK_ZONE_SWITCH_MIN_SEC", 1.0)

    # ── 事件 / 視窗持久化（說明書第一階段「事件與視窗資料設計」）──────────
    # 預設 None = 停用（維持 shadow 模式，不落地任何檔案）。給一個 .db 路徑
    # 即啟用 SQLite 事件表 lick_events + 視窗摘要表 lick_window_summary，
    # close_session() 時另匯出同名 .csv。可用環境變數覆寫。
    STORAGE_DB_PATH = _env_str("CAT_MONITORING_LICK_STORAGE_DB", "") or None
    WINDOW_SUMMARY_SEC = _env_float("CAT_MONITORING_LICK_WINDOW_SEC", 60.0)

    # ── Node-RED 推送設定 ─────────────────────────────────────────────────
    # 主機/port 預設跟主專案共用（見檔案開頭說明）；CAT_MONITORING_LICK_NODERED_URL
    # 可整條網址單獨覆寫，不受 NodeRedConfig.HOST/PORT 影響。
    NODERED_URL = _env_str(
        "CAT_MONITORING_LICK_NODERED_URL",
        f"http://{_NodeRedConfig.HOST}:{_NodeRedConfig.PORT}/lick_zone_result",
    )
    # 逾時刻意比主流程的 NodeRedConfig.TIMEOUT（預設 2 秒）短很多：這是主
    # YOLO/ST-GCN 推論迴圈裡的旁支輸出，寧可偶爾漏送一筆也不要卡住主迴圈
    # 等 Node-RED 回應，跟主流程「值得等」的推送語意不同，故不共用同一個
    # 設定值，但一樣開放獨立覆寫。
    NODERED_TIMEOUT = _env_float("CAT_MONITORING_LICK_NODERED_TIMEOUT", 0.3)
