"""
Geometric helpers and lick-zone contact detection.

All functions are pure (no side effects, no I/O).
"""

import math
from typing import Optional, Tuple

import numpy as np

from plugins.lick_stage.config import LickConfig as _C

# Precomputed ellipse boundary angles (module-level for performance)
_ANGLES = np.linspace(0.0, 2.0 * np.pi, _C.ELLIPSE_SAMPLES, endpoint=False)
_ECOS = np.cos(_ANGLES)
_ESIN = np.sin(_ANGLES)


# ── Private geometry primitives ───────────────────────────────────────────────


def _point_in_oriented_ellipse(
    point, center, axis_u, axis_v, radius_u, radius_v
) -> bool:
    rel = point - center
    u = float(np.dot(rel, axis_u))
    v = float(np.dot(rel, axis_v))
    ru2 = max(float(radius_u) ** 2, 1e-9)
    rv2 = max(float(radius_v) ** 2, 1e-9)
    return (u * u) / ru2 + (v * v) / rv2 <= 1.0 + 1e-9


def _sample_ellipse_boundary(center, axis_u, axis_v, radius_u, radius_v):
    c = np.asarray(center, dtype=np.float64)
    eu = np.asarray(axis_u, dtype=np.float64)
    ev = np.asarray(axis_v, dtype=np.float64)
    return (
        c
        + np.outer(_ECOS * float(radius_u), eu)
        + np.outer(_ESIN * float(radius_v), ev)
    )


def _distance_point_to_segment(point, seg_start, seg_end) -> float:
    p = np.asarray(point, dtype=np.float64)
    a = np.asarray(seg_start, dtype=np.float64)
    b = np.asarray(seg_end, dtype=np.float64)
    ab = b - a
    ab2 = float(ab[0]) ** 2 + float(ab[1]) ** 2
    if ab2 < 1e-12:
        return math.hypot(float(p[0] - a[0]), float(p[1] - a[1]))
    pa = p - a
    t = max(
        0.0, min(1.0, (float(pa[0]) * float(ab[0]) + float(pa[1]) * float(ab[1])) / ab2)
    )
    return math.hypot(float(pa[0]) - t * float(ab[0]), float(pa[1]) - t * float(ab[1]))


def _compute_strip_corners(p0, p1, half_width):
    """Return 4 corners (CCW) of a rectangle around segment p0-p1, or None."""
    seg = p1 - p0
    length = math.hypot(float(seg[0]), float(seg[1]))
    if length < 1e-6:
        return None
    axis = seg / length
    normal = np.array([-float(axis[1]), float(axis[0])], dtype=np.float64)
    off = normal * half_width
    return [p0 + off, p1 + off, p1 - off, p0 - off]


def _point_in_polygon(point, polygon) -> bool:
    """Ray-casting point-in-polygon test with boundary tolerance."""
    p = np.asarray(point, dtype=np.float64)
    poly = np.asarray(polygon, dtype=np.float64)
    if poly.ndim != 2 or poly.shape[0] < 3:
        return False
    x, y = float(p[0]), float(p[1])
    n = poly.shape[0]
    inside = False
    for i in range(n):
        j = (i - 1) % n
        xi, yi = float(poly[i, 0]), float(poly[i, 1])
        xj, yj = float(poly[j, 0]), float(poly[j, 1])
        sx, sy = xj - xi, yj - yi
        rx, ry = x - xi, y - yi
        seg_norm = math.hypot(sx, sy)
        if seg_norm > 1e-9:
            area2 = abs(sx * ry - sy * rx)
            dotv = rx * sx + ry * sy
            if area2 / seg_norm <= 1e-6 and -1e-9 <= dotv <= sx * sx + sy * sy + 1e-9:
                return True
        dy = yj - yi
        if abs(dy) < 1e-12:
            dy = 1e-12
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / dy + xi):
            inside = not inside
    return inside


def _segments_intersect(p1, p2, q1, q2) -> bool:
    def _orient(a, b, c):
        return float((b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]))

    def _on_seg(a, b, c):
        return (
            min(float(a[0]), float(b[0])) - 1e-9
            <= float(c[0])
            <= max(float(a[0]), float(b[0])) + 1e-9
            and min(float(a[1]), float(b[1])) - 1e-9
            <= float(c[1])
            <= max(float(a[1]), float(b[1])) + 1e-9
        )

    p1 = np.asarray(p1, dtype=np.float64)
    p2 = np.asarray(p2, dtype=np.float64)
    q1 = np.asarray(q1, dtype=np.float64)
    q2 = np.asarray(q2, dtype=np.float64)
    o1, o2 = _orient(p1, p2, q1), _orient(p1, p2, q2)
    o3, o4 = _orient(q1, q2, p1), _orient(q1, q2, p2)
    if (o1 * o2 < 0.0) and (o3 * o4 < 0.0):
        return True
    if abs(o1) <= 1e-9 and _on_seg(p1, p2, q1):
        return True
    if abs(o2) <= 1e-9 and _on_seg(p1, p2, q2):
        return True
    if abs(o3) <= 1e-9 and _on_seg(q1, q2, p1):
        return True
    if abs(o4) <= 1e-9 and _on_seg(q1, q2, p2):
        return True
    return False


def _polygons_intersect(poly_a, poly_b) -> bool:
    a = np.asarray(poly_a, dtype=np.float64)
    b = np.asarray(poly_b, dtype=np.float64)
    if a.ndim != 2 or b.ndim != 2 or a.shape[0] < 3 or b.shape[0] < 3:
        return False
    for pa in a:
        if _point_in_polygon(pa, b):
            return True
    for pb in b:
        if _point_in_polygon(pb, a):
            return True
    na, nb = a.shape[0], b.shape[0]
    for i in range(na):
        a0, a1 = a[i], a[(i + 1) % na]
        for j in range(nb):
            if _segments_intersect(a0, a1, b[j], b[(j + 1) % nb]):
                return True
    return False


def trap_dir_from_perp(trap_perp):
    """梯形延伸方向：永遠垂直於 trap_perp，且強制指向影像座標系「下方」（y 遞增方向）。

    貓咪不會倒著走路/理毛，鼻子（窄邊）在畫面上方、身體端（寬邊）在畫面下方
    是可以無條件成立的物理假設，不需要依賴「朝向 body_center」這種容易被雜訊
    干擾的判斷。這也讓 trap_dir 完全由 trap_perp 決定，不再是獨立的雜訊來源
    ——只要 trap_perp 穩定，trap_dir 就保證穩定，且短邊（nose 端）保證在上面。

    2026-09-11 M5 兩次試過拿掉這個「影像下方」先驗，改用跟拍攝角度無關的
    參照向量，三支影片（lick_28/lick_3/lick_31）實測後都撤回：
    - 第一次用 body_axis_unit（chest→hip，脊椎方向）：lick_28/lick_3 退步
      8~11 個百分點。診斷發現舔毛時頭常轉向舔身體某處，頭部朝向本來就會
      跟脊椎方向脫鉤，脊椎方向根本不是正確參照。
    - 第二次改用 head_axis_unit（nose→chest，頭部自己朝身體的方向）：退步
      幅度縮小到 2~7 個百分點，但仍測不贏這個舊版本。診斷發現更深層的原因：
      頭低下去舔前爪等動作時，鼻子已經移動到胸口下方伸向目標，這時候不管是
      脊椎方向還是頭部朝向都不能準確代表「梯形該往哪延伸」——目標（爪子/
      四肢）在家用攝影機視角下幾乎總是在頭部下方（重力關係），這跟頭部/
      身體朝向本身沒有直接關係，「影像下方」反而是更貼近這個實際攝影條件
      的先驗。
    - 結論：只有這 3 支類似居家視角的影片，不足以驗證「不依賴影像下方」的
      設計是否在其他拍攝角度（例如真正的俯視、貓咪倒臥等）更好，兩次替代
      方案都測不過這個舊版本，故維持現狀，待有更多不同拍攝角度的影片再
      重新評估。詳見 舔拭行為二階段分析模組說明.md 的「三階段重構：進度
      總表與下次接續」。
    """
    trap_perp = np.asarray(trap_perp, dtype=np.float64)
    d = np.array([-float(trap_perp[1]), float(trap_perp[0])], dtype=np.float64)
    if d[1] < 0.0:
        d = -d
    return d


def _compute_midback_angle_deg(chest, midback, hip) -> float:
    """算 Chest-MidBack-Hip 夾角（度，MidBack 為頂點）。

    跟 processors/skeleton_quality_assessment.py 的 compute_midback_angle()
    是同一套幾何公式，這裡另外重新實作一份（不 import processors/ 模組），
    以維持本 plugin 低耦合、可獨立抽離的既有設計原則（見本檔案開頭
    docstring）。呼叫端已經確認過三個關鍵點的信心值，這裡不重複檢查，
    只在兩個向量長度太短（幾乎重疊）時回傳 NaN。
    """
    chest = np.asarray(chest, dtype=np.float64)
    midback = np.asarray(midback, dtype=np.float64)
    hip = np.asarray(hip, dtype=np.float64)
    v1 = chest - midback
    v2 = hip - midback
    n1 = float(np.linalg.norm(v1))
    n2 = float(np.linalg.norm(v2))
    if n1 < 1e-6 or n2 < 1e-6:
        return float("nan")
    cos_angle = float(np.clip(np.dot(v1, v2) / (n1 * n2), -1.0, 1.0))
    return float(np.degrees(np.arccos(cos_angle)))


def _curvature_size_boost(midback_angle_deg: float) -> float:
    """依 Chest-MidBack-Hip 夾角（脊椎彎曲程度指標）線性內插出梯形縮放倍率。

    夾角越接近 CURVATURE_ANGLE_MAX_DEG（越直）→ 倍率越接近 CURVATURE_BOOST_MIN；
    夾角越接近 CURVATURE_ANGLE_MIN_DEG（越彎/蜷曲）→ 倍率越接近 CURVATURE_BOOST_MAX
    ——跟距離百分比版本方向相反（角度是遞減指標，越彎角度越小），故分子用
    CURVATURE_ANGLE_MAX_DEG 減去角度而非角度本身。

    純函式：輸入 NaN 或無效值時回傳 1.0（不縮放），維持與未量測 mid_back
    時完全一致的既有行為。內插區間見 config.py 的 CURVATURE_* 常數說明。
    """
    if midback_angle_deg is None or not math.isfinite(midback_angle_deg):
        return 1.0
    span = _C.CURVATURE_ANGLE_MAX_DEG - _C.CURVATURE_ANGLE_MIN_DEG
    if span <= 1e-9:
        return 1.0
    t = (_C.CURVATURE_ANGLE_MAX_DEG - midback_angle_deg) / span
    t = max(0.0, min(1.0, t))
    return _C.CURVATURE_BOOST_MIN + t * (
        _C.CURVATURE_BOOST_MAX - _C.CURVATURE_BOOST_MIN
    )


def build_nose_trapezoid(
    nose, trap_perp, trap_dir, trap_top_half, trap_bot_half, trap_height
):
    """Pure helper: rebuild the 4 trapezoid corners from already-decided direction
    vectors. Exposed so callers (e.g. LickAnalyzer) can recompute the trapezoid
    after temporally stabilizing trap_perp/trap_dir, without duplicating the
    corner-layout math."""
    nose = np.asarray(nose, dtype=np.float64)
    trap_perp = np.asarray(trap_perp, dtype=np.float64)
    trap_dir = np.asarray(trap_dir, dtype=np.float64)
    trap_bottom = nose + trap_dir * trap_height
    return np.asarray(
        [
            nose - trap_perp * trap_top_half,
            nose + trap_perp * trap_top_half,
            trap_bottom + trap_perp * trap_bot_half,
            trap_bottom - trap_perp * trap_bot_half,
        ],
        dtype=np.float64,
    )


def _polygon_aabb(poly) -> Tuple[float, float, float, float]:
    p = np.asarray(poly, dtype=np.float64)
    if p.ndim != 2 or p.shape[0] < 1:
        return float("nan"), float("nan"), float("nan"), float("nan")
    return (
        float(np.min(p[:, 0])),
        float(np.min(p[:, 1])),
        float(np.max(p[:, 0])),
        float(np.max(p[:, 1])),
    )


def _aabb_overlap(a, b) -> bool:
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    return not (ax2 < bx1 or bx2 < ax1 or ay2 < by1 or by2 < ay1)


def _polygon_contacts_circle(poly_pts, center, radius) -> bool:
    poly = np.asarray(poly_pts, dtype=np.float64)
    if poly.ndim != 2 or poly.shape[0] < 3:
        return False
    c = np.asarray(center, dtype=np.float64)
    r = max(float(radius), 0.0)
    if r <= 0.0:
        return False
    if not _aabb_overlap(
        _polygon_aabb(poly),
        (float(c[0] - r), float(c[1] - r), float(c[0] + r), float(c[1] + r)),
    ):
        return False
    if _point_in_polygon(c, poly):
        return True
    for p in poly:
        if math.hypot(float(p[0]) - float(c[0]), float(p[1]) - float(c[1])) <= r + 1e-9:
            return True
    n = poly.shape[0]
    for i in range(n):
        if _distance_point_to_segment(c, poly[i], poly[(i + 1) % n]) <= r + 1e-9:
            return True
    return False


def _polygon_contacts_oriented_ellipse(
    poly_pts, center, axis_u, axis_v, radius_u, radius_v
) -> bool:
    poly = np.asarray(poly_pts, dtype=np.float64)
    if poly.ndim != 2 or poly.shape[0] < 3:
        return False
    c = np.asarray(center, dtype=np.float64)
    eu = np.asarray(axis_u, dtype=np.float64)
    ev = np.asarray(axis_v, dtype=np.float64)
    ru, rv = float(radius_u), float(radius_v)
    ex = abs(float(eu[0])) * ru + abs(float(ev[0])) * rv
    ey = abs(float(eu[1])) * ru + abs(float(ev[1])) * rv
    if not _aabb_overlap(
        _polygon_aabb(poly),
        (float(c[0] - ex), float(c[1] - ey), float(c[0] + ex), float(c[1] + ey)),
    ):
        return False
    if _point_in_polygon(c, poly):
        return True
    for p in poly:
        if _point_in_oriented_ellipse(p, c, eu, ev, ru, rv):
            return True
    for p in _sample_ellipse_boundary(c, eu, ev, ru, rv):
        if _point_in_polygon(p, poly):
            return True
    return False


# ── Hybrid body scale (M5) ──────────────────────────────────────────────────


def _bbox_diagonal(kpts, kpt_conf) -> float:
    """所有信心足夠（> LIMB_CONF_THRESHOLD，最低的既有門檻）關鍵點的 bbox 對角線。

    只在 chest-hip 折線/直線長度都退化到不可信時當保底，不要求任何特定關鍵點，
    純粹用「畫面上偵測到的貓咪範圍」估計尺度。
    """
    pts = [
        np.asarray(kpts[i], dtype=np.float64)
        for i in range(len(kpt_conf))
        if float(kpt_conf[i]) > _C.LIMB_CONF_THRESHOLD
    ]
    if len(pts) < 2:
        return float("nan")
    arr = np.asarray(pts, dtype=np.float64)
    span = arr.max(axis=0) - arr.min(axis=0)
    return math.hypot(float(span[0]), float(span[1]))


def _compute_body_scale(
    kpts, kpt_conf, chest, hip, mid_back, mid_back_ok: bool, chest_hip_len: float
) -> Tuple[float, str]:
    """混合尺度：取代舊的絕對像素夾鉗（見 config.py 移除說明）。

    優先序：chest-midback-hip 折線長（抵抗蜷曲造成的直線距離壓縮，跟
    curvature_boost 想解決的問題同源，但這裡補的是 eff_len 本身）→
    chest-hip 直線距離 → bbox 對角線 × BBOX_TO_BODY_LEN_RATIO。
    """
    if mid_back_ok and mid_back is not None:
        seg1 = chest - mid_back
        seg2 = mid_back - hip
        spine_len = math.hypot(float(seg1[0]), float(seg1[1])) + math.hypot(
            float(seg2[0]), float(seg2[1])
        )
        if spine_len > _C.SCALE_DEGENERATE_LEN_PX:
            return spine_len, "spine_path"

    if chest_hip_len > _C.SCALE_DEGENERATE_LEN_PX:
        return chest_hip_len, "chest_hip"

    bbox_diag = _bbox_diagonal(kpts, kpt_conf)
    if math.isfinite(bbox_diag) and bbox_diag > 1e-6:
        return bbox_diag * _C.BBOX_TO_BODY_LEN_RATIO, "bbox_fallback"

    return max(chest_hip_len, 1e-6), "degenerate"


# ── Limb region builders ──────────────────────────────────────────────────────


def _build_limb_joint_targets(kpts, kpt_conf, eff_len: float) -> list:
    """Circle regions at each paw keypoint."""
    paw_radius = max(1e-6, eff_len * _C.LIMB_PAW_CIRCLE_R_RATIO * _C.LIMB_CONTACT_SCALE)
    targets = []
    for group, _knee_idx, paw_idx in _C.LIMB_SEGMENTS:
        if float(kpt_conf[paw_idx]) > _C.LIMB_CONF_THRESHOLD:
            targets.append(
                {
                    "group": group,
                    "center": np.asarray(kpts[paw_idx], dtype=np.float64),
                    "radius": paw_radius,
                }
            )
    return targets


def _build_limb_strip_targets(kpts, kpt_conf, eff_len: float) -> list:
    """Rectangle strips along knee-to-paw segments."""
    half_w = max(1e-6, eff_len * _C.LIMB_STRIP_HW_RATIO * _C.LIMB_CONTACT_SCALE)
    edge_gap = max(0.0, eff_len * _C.LIMB_STRIP_EDGE_GAP * _C.LIMB_CONTACT_SCALE)
    paw_radius = max(1e-6, eff_len * _C.LIMB_PAW_CIRCLE_R_RATIO * _C.LIMB_CONTACT_SCALE)
    strips = []
    for group, knee_idx, paw_idx in _C.LIMB_SEGMENTS:
        if not (
            float(kpt_conf[knee_idx]) > _C.LIMB_CONF_THRESHOLD
            and float(kpt_conf[paw_idx]) > _C.LIMB_CONF_THRESHOLD
        ):
            continue
        knee = np.asarray(kpts[knee_idx], dtype=np.float64)
        paw = np.asarray(kpts[paw_idx], dtype=np.float64)
        seg = paw - knee
        seg_len = math.hypot(float(seg[0]), float(seg[1]))
        if seg_len < 1e-6:
            continue
        axis = seg / seg_len
        s_start = knee + axis * edge_gap
        s_end = paw - axis * (paw_radius + edge_gap)
        if math.hypot(float((s_end - s_start)[0]), float((s_end - s_start)[1])) < 1e-3:
            continue
        corners = _compute_strip_corners(s_start, s_end, half_w)
        if corners is None:
            continue
        strips.append(
            {
                "group": group,
                "p0": s_start,
                "p1": s_end,
                "corners": corners,
            }
        )
    return strips


# ── Public API ────────────────────────────────────────────────────────────────


def compute_geometry(kpts, kpt_conf) -> Optional[dict]:
    """
    Build head/body geometry dict from keypoints.

    Returns None when required keypoints (nose, chest, hip) are missing.
    """
    if kpts is None or kpt_conf is None:
        return None

    left_ok = float(kpt_conf[_C.KP_LEFT_EAR]) > _C.EAR_CONF_THRESHOLD
    right_ok = float(kpt_conf[_C.KP_RIGHT_EAR]) > _C.EAR_CONF_THRESHOLD
    nose_ok = float(kpt_conf[_C.KP_NOSE]) >= _C.NOSE_CONF_THRESHOLD
    chest_ok = float(kpt_conf[_C.KP_CHEST]) > _C.EAR_CONF_THRESHOLD
    hip_ok = float(kpt_conf[_C.KP_HIP]) > _C.EAR_CONF_THRESHOLD

    if not (nose_ok and chest_ok and hip_ok):
        return None

    nose = np.asarray(kpts[_C.KP_NOSE], dtype=np.float64)
    chest = np.asarray(kpts[_C.KP_CHEST], dtype=np.float64)
    hip = np.asarray(kpts[_C.KP_HIP], dtype=np.float64)

    if left_ok and right_ok:
        left_ear = np.asarray(kpts[_C.KP_LEFT_EAR], dtype=np.float64)
        right_ear = np.asarray(kpts[_C.KP_RIGHT_EAR], dtype=np.float64)
        ear_center = 0.5 * (left_ear + right_ear)
    else:
        left_ear = right_ear = None
        ear_center = nose.copy()

    body_axis = hip - chest
    body_len = math.hypot(float(body_axis[0]), float(body_axis[1]))
    if body_len < 1e-6:
        return None
    body_axis_unit = body_axis / body_len
    body_normal = np.array(
        [-float(body_axis_unit[1]), float(body_axis_unit[0])], dtype=np.float64
    )
    body_center = 0.5 * (chest + hip)

    region_rx = max(1e-6, 0.5 * _C.BODY_ELLIPSE_W_RATIO * body_len)
    region_ry = max(1e-6, 0.5 * _C.BODY_ELLIPSE_H_RATIO * body_len)

    # Chest-MidBack-Hip 夾角（脊椎彎曲程度指標，度）。mid_back 信心不足時
    # 視為無法判斷彎曲程度，boost 退回 1.0（不縮放）。公式對齊 processors/
    # skeleton_quality_assessment.py 的 compute_midback_angle()（見
    # _compute_midback_angle_deg() 說明）。
    mid_back_ok = float(kpt_conf[_C.KP_MID_BACK]) > _C.EAR_CONF_THRESHOLD
    if mid_back_ok:
        mid_back = np.asarray(kpts[_C.KP_MID_BACK], dtype=np.float64)
        midback_angle_deg = _compute_midback_angle_deg(chest, mid_back, hip)
    else:
        mid_back = None
        midback_angle_deg = float("nan")
    curvature_boost = _curvature_size_boost(midback_angle_deg)

    # 混合尺度（M5，取代舊的絕對像素夾鉗）：見 _compute_body_scale() 說明。
    eff_len, scale_source = _compute_body_scale(
        kpts, kpt_conf, chest, hip, mid_back, mid_back_ok, body_len
    )

    # Nose contact trapezoid
    trap_height = max(
        1e-6,
        _C.NOSE_TRAP_THICKNESS_RATIO
        * _C.NOSE_TRAP_THICKNESS_SCALE
        * eff_len
        * curvature_boost,
    )
    trap_top_half = max(
        1e-6,
        0.5
        * _C.NOSE_TRAP_TOP_W_RATIO
        * _C.NOSE_TRAP_W_SCALE
        * eff_len
        * curvature_boost,
    )
    trap_bot_half = max(
        1e-6,
        0.5
        * _C.NOSE_TRAP_BOT_W_RATIO
        * _C.NOSE_TRAP_W_SCALE
        * eff_len
        * curvature_boost,
    )

    if left_ok and right_ok:
        ear_line = right_ear - left_ear
        ear_line_norm = math.hypot(float(ear_line[0]), float(ear_line[1]))
        trap_perp = (
            ear_line / ear_line_norm
            if ear_line_norm > 1e-9
            else np.array([1.0, 0.0], dtype=np.float64)
        )
    else:
        bn = math.hypot(float(body_normal[0]), float(body_normal[1]))
        trap_perp = (
            body_normal / bn if bn > 1e-9 else np.array([1.0, 0.0], dtype=np.float64)
        )

    trap_dir = trap_dir_from_perp(trap_perp)

    nose_trap = build_nose_trapezoid(
        nose, trap_perp, trap_dir, trap_top_half, trap_bot_half, trap_height
    )

    limb_targets = _build_limb_joint_targets(kpts, kpt_conf, eff_len)
    limb_strip_targets = _build_limb_strip_targets(kpts, kpt_conf, eff_len)

    return {
        "nose": nose,
        "ear_center": ear_center,
        "body_center": body_center,
        "body_normal": body_normal,
        "body_axis_unit": body_axis_unit,
        "body_len": body_len,
        "mid_back": mid_back,  # (2,) pixel coords，或 None（信心不足）；供 overlay 標角度數字用
        "midback_angle_deg": midback_angle_deg,
        "curvature_boost": curvature_boost,
        "eff_len": eff_len,  # 混合尺度後的有效身體長度（M5），供 debug/overlay 使用
        "scale_source": scale_source,  # "spine_path" / "chest_hip" / "bbox_fallback" / "degenerate"
        "region_rx": region_rx,
        "region_ry": region_ry,
        "nose_contact_trapezoid": nose_trap,
        "limb_targets": limb_targets,
        "limb_strip_targets": limb_strip_targets,
        # 未經時序穩定的原始方向向量/尺寸，供 LickAnalyzer 做跨幀翻轉感知平滑後
        # 用 build_nose_trapezoid() 重建梯形（避免這裡的 pure function 持有狀態）
        "trap_perp": trap_perp,
        "trap_dir": trap_dir,
        "trap_top_half": trap_top_half,
        "trap_bot_half": trap_bot_half,
        "trap_height": trap_height,
    }


def find_nearest_zone(target_geom) -> Tuple[str, float, bool]:
    """
    Test nose-contact trapezoid against all contact regions, scoring every
    intersecting candidate instead of just picking whichever is nearest by
    raw distance (M5：候選評分 + AMBIGUOUS，取代舊版純距離排序)。

    每個命中候選都換算成正規化分數 geometry_score ∈ [0,1]（1 - 距離/該候選
    區域的特徵尺度：身體橢圓用 region_ry，四肢用腳尖圓半徑），分數越接近 1
    代表鼻尖越貼近該區域中心/骨架。當最高分跟次高分（不同 zone）差距小於
    AMBIGUITY_MARGIN 時，回傳 ZONE_AMBIGUOUS 而不是武斷選一個——這種情況
    代表鼻尖確實碰觸到身體，只是幾何上無法可靠分辨是哪個相鄰區域（例如
    正好在身體與前肢交界處）。

    Returns (zone_label, geometry_score, hit)。
    zone_label 可能是 BODY_CENTER, FL, FR, HL, HR, AMBIGUOUS, 或 NO_TARGET。
    """
    if target_geom is None:
        return _C.ZONE_NO_TARGET, 0.0, False

    nose_pt = target_geom.get("nose")
    nose_trap = np.asarray(
        target_geom.get("nose_contact_trapezoid", []), dtype=np.float64
    )
    if nose_pt is None or nose_trap.ndim != 2 or nose_trap.shape[0] != 4:
        return _C.ZONE_NO_TARGET, 0.0, False

    candidates = []  # (score, zone_label)

    # Body center ellipse
    if _polygon_contacts_oriented_ellipse(
        nose_trap,
        target_geom["body_center"],
        np.asarray(target_geom["body_normal"], dtype=np.float64),
        np.asarray(target_geom["body_axis_unit"], dtype=np.float64),
        float(target_geom["region_rx"]),
        float(target_geom["region_ry"]),
    ):
        d_body = _distance_point_to_segment(
            nose_pt,
            target_geom["body_center"]
            - 0.5
            * float(target_geom["body_len"])
            * np.asarray(target_geom["body_axis_unit"], dtype=np.float64),
            target_geom["body_center"]
            + 0.5
            * float(target_geom["body_len"])
            * np.asarray(target_geom["body_axis_unit"], dtype=np.float64),
        )
        body_scale = max(float(target_geom["region_ry"]), 1e-6)
        score = max(0.0, min(1.0, 1.0 - d_body / body_scale))
        candidates.append((score, _C.ZONE_BODY))

    # Limb paw circles (group → minimum distance)
    limb_dist = {g: float("inf") for g in ("FL", "FR", "HL", "HR")}
    for limb in target_geom.get("limb_targets", []):
        center = np.asarray(limb["center"], dtype=np.float64)
        if _polygon_contacts_circle(nose_trap, center, float(limb["radius"])):
            g = str(limb.get("group", ""))
            d = math.hypot(
                float(nose_pt[0]) - float(center[0]),
                float(nose_pt[1]) - float(center[1]),
            )
            if g in limb_dist and d < limb_dist[g]:
                limb_dist[g] = d

    # Limb strip rectangles
    for strip in target_geom.get("limb_strip_targets", []):
        corners = strip.get("corners")
        if corners is None or len(corners) != 4:
            continue
        if _polygons_intersect(nose_trap, np.asarray(corners, dtype=np.float64)):
            g = str(strip.get("group", ""))
            d = _distance_point_to_segment(nose_pt, strip["p0"], strip["p1"])
            if g in limb_dist and d < limb_dist[g]:
                limb_dist[g] = d

    # 四肢的特徵尺度：paw circle 半徑（跟 strip 半寬同一比例級數，兩者共用
    # 這一個尺度已足夠當正規化分母，見 config.py LIMB_PAW_CIRCLE_R_RATIO/
    # LIMB_STRIP_HW_RATIO 的說明）。
    limb_scale = max(
        float(target_geom.get("eff_len", 0.0))
        * _C.LIMB_PAW_CIRCLE_R_RATIO
        * _C.LIMB_CONTACT_SCALE,
        1e-6,
    )
    for group, dist in limb_dist.items():
        if math.isfinite(dist):
            score = max(0.0, min(1.0, 1.0 - dist / limb_scale))
            candidates.append((score, group))

    if not candidates:
        return _C.ZONE_NO_TARGET, 0.0, False

    # 同一個 zone 可能同時被多個候選命中（例如四肢的 paw circle 跟 strip）；
    # 每個 zone 只留最高分，才能正確比較「不同 zone 之間」是否構成 AMBIGUOUS
    best_per_zone: dict = {}
    for score, zone in candidates:
        if zone not in best_per_zone or score > best_per_zone[zone]:
            best_per_zone[zone] = score
    ranked = sorted(best_per_zone.items(), key=lambda kv: kv[1], reverse=True)

    best_zone, best_score = ranked[0]
    if len(ranked) >= 2 and (best_score - ranked[1][1]) < _C.AMBIGUITY_MARGIN:
        return _C.ZONE_AMBIGUOUS, best_score, True
    return best_zone, best_score, True
